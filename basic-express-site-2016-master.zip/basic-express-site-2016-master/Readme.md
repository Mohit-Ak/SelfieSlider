# Basic Express Site (2016 Edition)

A simple website in node js to accompany a blog post.

## Setup

```
npm i
npm run build
npm start

# development mode (watches for source changes)
npm run watch
```

## Screenshot

![Screenshot](https://raw.githubusercontent.com/bengourley/basic-express-site-2016/master/screenshot.png)
